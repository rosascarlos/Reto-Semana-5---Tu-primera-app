//
//  ViewController.swift
//  24 - Hamburguesas
//
//  Created by Carlos Rosas on 10/10/16.
//  Copyright © 2016 Carlos Rosas. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    /*
     a. Una instancia de la clase ColeccionDePaises.
     b. Una instancia de la clase ColeccionDeHamburguesas.
     c. Un @IBoutlet para la etiqueta de país.
     d. Un @IBoutlet para la etiqueta de hamburguesa.
     e. Un @IBAction para implementar cambiar de país y de hamburguesa.
     5. Al presionar el botón debes cambiar el país y la hamburguesa que se despliegan en las etiquetas, de manera opcional cambia el color de fondo como se realizo en los videos del módulo 5.*/
    
    let paises = ColeccionDePaises.Paises()
    let hamburguesas = ColeccionDeHamburguesas.Hamburguesas()
    let colores = Colores()
    
    @IBOutlet weak var lblPais: UILabel!
    @IBOutlet weak var lblHamburguesa: UILabel!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func cambiarPaisHamburguesa() {
        
        view.backgroundColor = colores.regresaColorAleatorio()
        
        lblPais.text = paises.obtenPais()
        
        lblHamburguesa.text = hamburguesas.obtenHamburguesa()
        
    }

}

